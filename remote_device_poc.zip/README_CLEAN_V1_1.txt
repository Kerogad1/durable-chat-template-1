CLEAN V1.1 REVIEW NOTES

Fixed:
- Unified Agent preferences; no more kero_prefs vs AgentPreferences mismatch.
- AgentService is the only persistent connection service.
- MainActivity starts AgentService, avoiding duplicate WebSocket connections.
- AgentService initializes AppContextHolder and restores the saved connection.
- BootReceiver only restores the Agent when it is configured.
- Agent reconnect now uses exponential backoff (2s -> 60s) and WebSocket ping.
- Controller has a real status callback and auto-connects from saved settings.
- Controller navigation now scrolls to real sections instead of only showing a Toast.
- Controller binary receiver now displays screen/camera JPEG frames and plays audio chunks.
- Accessibility screenshot uses the official screenshot capability and binary JPEG frames.
- App restrictions are persisted across process restarts.
- Device admin receiver added for the remote-lock feature.
- Media FGS types are selected according to camera/microphone use.
- Screen recorder uses the mediaProjection foreground-service type.
- Old KeroCoreService was removed from the active project.
- WAKE_LOCK and battery-optimization exemption permissions were removed from the Agent manifest.
- Agent/Controller permissions are separated by flavor manifests.
- Server keeps a stable Pair Code and logs CONNECT/CLOSE events.
- A local build.bat uses the existing Gradle 8.9 and Android SDK; it does not download them.

Not claimed as fully implemented:
- WebRTC/H.264 live streaming.
- A full SAF-based file browser.
- Production-grade multi-device/cloud relay.
- Google Play release signing/AAB.
These need a separate release-hardening pass.

Note: The clean bundle does not include a secret-code mechanism whose purpose is to hide a remote-management app from the device user. The normal launcher remains available.
