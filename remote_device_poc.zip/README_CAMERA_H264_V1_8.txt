Remote Device Clean V1.8 - Camera H.264 / Front-Back / Smooth Streaming

Changes:
- Camera transport changed from per-frame JPEG to hardware H.264 (MediaCodec) when supported.
- Controller receives H.264 access units over the existing WebSocket binary channel and decodes them with MediaCodec directly to TextureView.
- Camera controls now expose separate rear/front start buttons plus stop and switch.
- Camera targets 1920x1080@30 when supported; for <=1280x720 it can use up to 60 FPS when the camera reports that FPS range.
- Low-latency decoder mode is enabled on Android 11+ when supported.
- The media service remains a visible foreground service and requires the official CAMERA permission.
- The server protocol remains unchanged; it relays binary frames transparently.

Verification performed in the build environment:
- All Android XML files parsed successfully.
- Kotlin brace balance checked for modified files.
- New resource IDs referenced by ControllerActivity exist in XML.
- Camera command names are wired in ControllerActivity -> RemoteConnection -> MediaControlService.

Runtime build note:
- Full Android/Gradle runtime build was not executed in this environment because the bundled source archive does not include the user's local Android SDK/Gradle toolchain.
