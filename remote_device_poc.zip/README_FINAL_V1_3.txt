REMOTE DEVICE CLEAN V1.3 - BUILD READY
=======================================

This bundle is a cleaned/build-ready source package for the Android university POC.

Included:
- Phone Assistant (Agent) flavor
- Remote (Controller) flavor
- WebSocket server with pair-code connection
- Screen control through Android Accessibility Service
- Screen streaming through Android MediaProjection/Accessibility screenshot path
- Camera and microphone services using Android foreground-service types
- Device/battery/network/app/call/SMS/file information providers
- Device-admin lock and alarm
- Notification listener service
- Persistent AgentService and boot receiver registration
- Local build script using the existing tools/gradle-8.9 and tools/android-sdk

Important:
- The bundle does NOT bypass Android permissions or privacy indicators.
- Camera, microphone, screen capture, Accessibility, SMS, call log, location,
  notification listener, and device-admin features require the corresponding
  Android user/system authorization.
- A successful source/static package cannot guarantee behavior on every phone
  until the APK is installed and tested on the target Android version.
- The provided environment here cannot run the Windows Android Gradle toolchain;
  therefore no claim is made that an APK was built in this environment.

Build on the user's Windows PC:
1. Keep the existing tools folder beside this project:
   tools/gradle-8.9/
   tools/android-sdk/
2. Run build.bat.
3. Output:
   android-agent/release/PhoneAssistant.apk
   android-agent/release/Remote.apk

The source was additionally patched so the Agent BootReceiver is declared and
launcher icon resource references that were missing from the bundle are removed.
