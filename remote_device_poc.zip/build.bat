@echo off
setlocal EnableExtensions

set "ROOT=%~dp0"
set "SDK=%ROOT%tools\android-sdk"
set "GRADLE=%ROOT%tools\gradle-8.9\bin\gradle.bat"
set "PROJECT=%ROOT%android-agent"
set "SDK_PROP=%SDK:\=/%"

echo ================================================
 echo   REMOTE DEVICE - LOCAL BUILD
echo ================================================
 echo.

if not exist "%GRADLE%" goto gradle_missing
if not exist "%SDK%\platforms\android-35" goto sdk_missing

echo sdk.dir=%SDK_PROP%>"%PROJECT%\local.properties"
cd /d "%PROJECT%"

echo [INFO] Cleaning and building Agent + Controller...
call "%GRADLE%" clean assembleAgentDebug assembleControllerDebug --no-daemon
if errorlevel 1 goto build_failed

if not exist release mkdir release
del /q release\*.apk 2>nul

copy /Y "app\build\outputs\apk\agent\debug\app-agent-debug.apk" "release\PhoneAssistant.apk" >nul
if errorlevel 1 goto copy_failed

copy /Y "app\build\outputs\apk\controller\debug\app-controller-debug.apk" "release\Remote.apk" >nul
if errorlevel 1 goto copy_failed

echo.
echo ================================================
echo BUILD SUCCESSFUL
echo.
echo Agent:
echo %PROJECT%\release\PhoneAssistant.apk
echo.
echo Controller:
echo %PROJECT%\release\Remote.apk
echo ================================================
pause
exit /b 0

:gradle_missing
echo [ERROR] Local Gradle not found:
echo %GRADLE%
echo.
echo Put the existing gradle-8.9 folder under tools\.
pause
exit /b 1

:sdk_missing
echo [ERROR] Android SDK platform 35 not found:
echo %SDK%
echo.
echo Use the Android SDK already installed on this PC.
pause
exit /b 1

:build_failed
echo.
echo BUILD FAILED
pause
exit /b 1

:copy_failed
echo.
echo Build succeeded, but APK copy failed.
pause
exit /b 1
