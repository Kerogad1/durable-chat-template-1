REMOTE DEVICE - CLEAN CONNECTION NOTES

The current clean build:
- uses AgentService for the persistent Agent connection;
- stores Agent settings in AgentPreferences;
- stores Controller settings in ControllerPreferences;
- restores the Agent connection after reboot when configured;
- reconnects with exponential backoff instead of a fixed 3-second loop;
- logs CONNECT/CLOSE events on the Node server;
- keeps the Pair Code in server/pair-code.txt.

Build with:
build.bat

The build uses the local Gradle 8.9 and local Android SDK only.
