@echo off
setlocal
set "ROOT=%~dp0"
set "SDK=%ROOT%tools\android-sdk"
set "PATH=%SDK%\platform-tools;%PATH%"

if not exist "%SDK%\platform-tools\adb.exe" (
  echo [ERROR] ADB not found: "%SDK%\platform-tools\adb.exe"
  pause
  exit /b 1
)
if not exist "%ROOT%android-agent\release\PhoneAssistant.apk" (
  echo [ERROR] PhoneAssistant.apk not found. Run build.bat first.
  pause
  exit /b 1
)
if not exist "%ROOT%android-agent\release\Remote.apk" (
  echo [ERROR] Remote.apk not found. Run build.bat first.
  pause
  exit /b 1
)

echo Connected devices:
adb devices

echo.
echo 1 = Phone Assistant (Agent)
echo 2 = Remote (Controller)
echo 3 = Both in sequence
echo.
choice /C 123 /N /M "Select: "
if errorlevel 3 goto both
if errorlevel 2 goto remote
if errorlevel 1 goto agent

goto done

:agent
adb install -r "%ROOT%android-agent\release\PhoneAssistant.apk"
goto done

:remote
adb install -r "%ROOT%android-agent\release\Remote.apk"
goto done

:both
adb install -r "%ROOT%android-agent\release\PhoneAssistant.apk"
if errorlevel 1 goto done
adb install -r "%ROOT%android-agent\release\Remote.apk"

goto done

done
pause
exit /b 0
