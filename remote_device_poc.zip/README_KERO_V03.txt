KERO Remote / Phone Assistant - v0.3

WHAT CHANGED IN THIS BUILD
--------------------------
1) The Android module now has two product flavors:
   - agent      -> Phone Assistant
   - controller -> Remote

2) Agent connection runs as a persistent foreground remote-messaging service.
   - Server URL + Pair Code are saved in SharedPreferences.
   - Closing the Agent UI does not clear the connection settings.
   - The service reconnects automatically after a network failure.
   - After reboot / app update, the agent connection service can start again.

3) Camera + microphone are prepared through MediaControlService.
   - Runtime permissions are checked before requesting them.
   - Once granted, they are not requested again unless the user revokes them,
     reinstalls the app, or Android otherwise resets the permission state.
   - Camera/microphone capture uses Android Foreground Service types.

4) Screen frames, camera JPEG frames, and microphone PCM chunks now have
   simple binary stream prefixes and the Node server relays binary WebSocket
   frames correctly.

5) ControllerActivity has remote camera / microphone controls and device info.

IMPORTANT ANDROID LIMITS
------------------------
- MediaProjection (screen sharing) on Android 14+ requires user consent for
  EACH new capture session. The app cannot legally/technically turn that into
  a one-time permanent permission.
- Camera and microphone background access is subject to Android foreground-
  service and while-in-use restrictions. The initial media service must be
  prepared while the Agent app is visible and the permissions are granted.
- Foreground services require a system notification. This notification is not
  something the app can remove while the service is running.
- Android's camera/microphone privacy indicators are left intact.

BUILD
-----
From:
  remote_device_poc\android-agent

Use the Gradle installation you already downloaded on the PC:
  ..\tools\gradle-8.9\bin\gradle.bat assembleAgentDebug assembleControllerDebug --no-daemon

APKs will be under:
  app\build\outputs\apk\agent\debug\
  app\build\outputs\apk\controller\debug\

SERVER
------
From:
  remote_device_poc\server

  npm install
  npm start

The server supports both JSON messages and binary WebSocket frames.
