Remote Device Clean V1.5

This revision fixes the build failure reported by Gradle:
- MediaControlService now implements Service.onBind() and returns null (started foreground service).
- Kotlin compilation is configured to run in-process to avoid Kotlin daemon connection failures on affected Windows setups.
- Main/Agent/Controller manifests remain separated to avoid duplicate Activity/Theme merge conflicts.
- Android XML resources/manifests were parsed successfully during static validation.

Runtime/build note: this package was statically validated here; final APK assembly still depends on the Android SDK/Gradle/JDK installed on the target PC.
