@echo off
setlocal
cd /d "%~dp0android-agent"

if exist app\build rmdir /s /q app\build
if exist .gradle rmdir /s /q .gradle
if exist .kotlin rmdir /s /q .kotlin

echo Build caches cleaned.
pause
